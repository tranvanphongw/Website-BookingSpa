// backend/controllers/payment.controller.js
const { poolConnect, sql } = require('../config/db');

// Lấy danh sách các giao dịch
const getPayments = async (req, res) => {
  try {
    await poolConnect;
    const result = await poolConnect.request().query('SELECT * FROM THANHTOAN');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Thực hiện thanh toán
const makePayment = async (req, res) => {
  const { MAKH, SOTIEN, NGAYTHANHTOAN } = req.body;
  try {
    await poolConnect;
    const request = poolConnect.request();
    await request
      .input('MAKH', sql.Int, MAKH)
      .input('SOTIEN', sql.Decimal, SOTIEN)
      .input('NGAYTHANHTOAN', sql.Date, NGAYTHANHTOAN)
      .query('INSERT INTO THANHTOAN (MAKH, SOTIEN, NGAYTHANHTOAN) VALUES (@MAKH, @SOTIEN, @NGAYTHANHTOAN)');
    res.json({ message: 'Thanh toán thành công' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { getPayments, makePayment };
