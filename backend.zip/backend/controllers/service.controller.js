// backend/controllers/service.controller.js
const { poolConnect, sql } = require('../config/db');

// Lấy danh sách dịch vụ
const getServices = async (req, res) => {
  try {
    await poolConnect;
    const result = await poolConnect.request().query('SELECT * FROM DICHVU');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Thêm dịch vụ mới
const addService = async (req, res) => {
  const { TENDICHVU, GIA } = req.body;
  try {
    await poolConnect;
    const request = poolConnect.request();
    await request
      .input('TENDICHVU', sql.NVarChar, TENDICHVU)
      .input('GIA', sql.Decimal, GIA)
      .query('INSERT INTO DICHVU (TENDICHVU, GIA) VALUES (@TENDICHVU, @GIA)');
    res.json({ message: 'Dịch vụ đã được thêm' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { getServices, addService };
