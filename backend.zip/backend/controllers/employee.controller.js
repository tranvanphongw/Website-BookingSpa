// backend/controllers/employee.controller.js
const { poolConnect, sql } = require('../config/db');

// Lấy danh sách nhân viên
const getEmployees = async (req, res) => {
  try {
    await poolConnect;
    const result = await poolConnect.request().query('SELECT * FROM NHANVIEN');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Thêm nhân viên mới
const addEmployee = async (req, res) => {
  const { TEN, CHUCVU, EMAIL, DTHOAI } = req.body;
  try {
    await poolConnect;
    const request = poolConnect.request();
    await request
      .input('TEN', sql.NVarChar, TEN)
      .input('CHUCVU', sql.VarChar, CHUCVU)
      .input('EMAIL', sql.VarChar, EMAIL)
      .input('DTHOAI', sql.VarChar, DTHOAI)
      .query('INSERT INTO NHANVIEN (TEN, CHUCVU, EMAIL, DTHOAI) VALUES (@TEN, @CHUCVU, @EMAIL, @DTHOAI)');
    res.json({ message: 'Nhân viên đã được thêm' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { getEmployees, addEmployee };
