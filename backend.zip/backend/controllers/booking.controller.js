// backend/controllers/booking.controller.js
const { poolConnect, sql } = require('../config/db');

// Lấy danh sách các booking
const getBookings = async (req, res) => {
  try {
    await poolConnect;
    const result = await poolConnect.request().query('SELECT * FROM LICHDAT');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Tạo booking mới
const addBooking = async (req, res) => {
  const { MAKH, MADV, NGAYDAT, TRANGTHAI } = req.body;
  try {
    await poolConnect;
    const request = poolConnect.request();
    await request
      .input('MAKH', sql.Int, MAKH)
      .input('MADV', sql.Int, MADV)
      .input('NGAYDAT', sql.Date, NGAYDAT)
      .input('TRANGTHAI', sql.VarChar, TRANGTHAI)
      .query('INSERT INTO LICHDAT (MAKH, MADV, NGAYDAT, TRANGTHAI) VALUES (@MAKH, @MADV, @NGAYDAT, @TRANGTHAI)');
    res.json({ message: 'Booking đã được tạo' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { getBookings, addBooking };
