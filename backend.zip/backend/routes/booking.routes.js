// === backend/routes/booking.routes.js ===
const express = require('express');
const router = express.Router();
const { poolConnect, sql } = require('../config/db');

// Get all bookings
router.get('/', async (req, res) => {
  try {
    await poolConnect;
    const result = await poolConnect.request().query('SELECT * FROM LICHDAT');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a new booking
router.post('/add', async (req, res) => {
  const { MAKH, MANV, MADV, THOIGIANBATDAU, THOIGIANKETTHUC } = req.body;
  try {
    await poolConnect;
    const request = poolConnect.request();
    await request
      .input('MAKH', sql.Int, MAKH)
      .input('MANV', sql.Int, MANV)
      .input('MADV', sql.Int, MADV)
      .input('THOIGIANBATDAU', sql.DateTime, THOIGIANBATDAU)
      .input('THOIGIANKETTHUC', sql.DateTime, THOIGIANKETTHUC)
      .query('INSERT INTO LICHDAT (MAKH, MANV, MADV, THOIGIANBATDAU, THOIGIANKETTHUC) VALUES (@MAKH, @MANV, @MADV, @THOIGIANBATDAU, @THOIGIANKETTHUC)');
    res.json({ message: 'Đặt lịch thành công' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
