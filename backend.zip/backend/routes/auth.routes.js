// === backend/routes/auth.routes.js ===
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { poolConnect, sql } = require('../config/db');

// Đăng ký khách hàng
router.post('/register', async (req, res) => {
  const { TEN, DCHI, DTHOAI, EMAIL, MATKHAU } = req.body;
  try {
    await poolConnect;
    const hashed = await bcrypt.hash(MATKHAU, 10);
    const request = poolConnect.request();
    await request
      .input('TEN', sql.NVarChar, TEN)
      .input('DCHI', sql.NVarChar, DCHI)
      .input('DTHOAI', sql.VarChar, DTHOAI)
      .input('EMAIL', sql.VarChar, EMAIL)
      .input('MATKHAU', sql.VarChar, hashed)
      .query('INSERT INTO KHACHHANG (TEN, DCHI, DTHOAI, EMAIL, MATKHAU) VALUES (@TEN, @DCHI, @DTHOAI, @EMAIL, @MATKHAU)');
    res.json({ message: 'Đăng ký thành công' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Đăng nhập khách hàng
router.post('/login', async (req, res) => {
  const { EMAIL, MATKHAU } = req.body;
  try {
    await poolConnect;
    const result = await poolConnect.request()
      .input('EMAIL', sql.VarChar, EMAIL)
      .query('SELECT * FROM KHACHHANG WHERE EMAIL = @EMAIL');

    const user = result.recordset[0];
    if (!user || !(await bcrypt.compare(MATKHAU, user.MATKHAU))) {
      return res.status(401).json({ error: 'Sai email hoặc mật khẩu' });
    }

    const token = jwt.sign({ MAKH: user.MAKH, role: 'KHACHHANG' }, process.env.SECRET_KEY);
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
