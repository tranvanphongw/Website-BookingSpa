// === backend/routes/service.routes.js ===
const express = require('express');
const router = express.Router();
const { poolConnect, sql } = require('../config/db');

// Get all services
router.get('/', async (req, res) => {
  try {
    await poolConnect;
    const result = await poolConnect.request().query('SELECT * FROM DICHVU');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a new service
router.post('/add', async (req, res) => {
  const { TEN, MOTA, GIATIEN } = req.body;
  try {
    await poolConnect;
    const request = poolConnect.request();
    await request
      .input('TEN', sql.NVarChar, TEN)
      .input('MOTA', sql.NVarChar, MOTA)
      .input('GIATIEN', sql.Int, GIATIEN)
      .query('INSERT INTO DICHVU (TEN, MOTA, GIATIEN) VALUES (@TEN, @MOTA, @GIATIEN)');
    res.json({ message: 'Dịch vụ được thêm thành công!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
