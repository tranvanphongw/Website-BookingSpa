const sql = require('mssql');
const dotenv = require('dotenv');

// Load thông tin cấu hình từ .env
dotenv.config();

const config = {
  user: process.env.DB_USER,        // Tên người dùng (Windows Authentication)
  password: process.env.DB_PASS,    // Mật khẩu người dùng (nếu có)
  server: process.env.DB_HOST,      // Tên máy chủ của SQL Server (PHONG\SQLEXPRESS)
  database: process.env.DB_NAME,    // Tên cơ sở dữ liệu
  options: {
    trustServerCertificate: true,   // Kết nối an toàn hơn
    encrypt: false                  // Đặt thành false nếu không sử dụng mã hóa SSL
  }
};

// Khởi tạo kết nối
const pool = new sql.ConnectionPool(config);
const poolConnect = pool.connect();

// Kiểm tra kết nối
poolConnect.then(() => {
  console.log('Kết nối tới cơ sở dữ liệu thành công!');
}).catch((err) => {
  console.error('Lỗi kết nối: ', err);
});

module.exports = { sql, pool, poolConnect };
