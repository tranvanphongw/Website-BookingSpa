module.exports = {
  partnerCode: 'MOMO',
  accessKey: 'F8BBA842ECF85',
  secretKey: 'K951B6PE1waDMi640xX08PD3vg6EkVlz',
  redirectUrl: 'https://af27-183-80-186-213.ngrok-free.app/api/payment/return',
  ipnUrl: 'https://af27-183-80-186-213.ngrok-free.app/api/payment/notify',
  requestType: 'payWithMethod',
};
